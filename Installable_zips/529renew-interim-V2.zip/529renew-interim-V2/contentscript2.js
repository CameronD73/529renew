// Cause 529andYou button to appear in Chrome menubar
chrome.extension.sendRequest({}, function(response){});